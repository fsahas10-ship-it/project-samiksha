"use client";

import Link from "next/link";

interface WishCardProps {
  wish: {
    id: number;
    title: string;
    description: string;
    price: number;
  };
}

export default function WishCard({ wish }: WishCardProps) {
  return (
    <div className="bg-white rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 p-6 border">

      <h2 className="text-2xl font-bold text-gray-900">
        {wish.title}
      </h2>

      <p className="text-gray-600 mt-3 min-h-[60px]">
        {wish.description}
      </p>

      <div className="mt-5 flex items-center justify-between">

        <span className="text-2xl font-bold text-blue-600">
          ₹{Number(wish.price).toLocaleString("en-IN")}
        </span>

      </div>

      <Link href={`/edit/${wish.id}`}>
        <button className="mt-6 w-full rounded-xl bg-black py-3 text-white hover:bg-gray-800 transition">
          Edit Wish
        </button>
      </Link>

    </div>
  );
}