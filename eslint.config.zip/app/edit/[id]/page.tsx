"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

export default function EditWishPage() {
  const params = useParams();
  const router = useRouter();

  const [wish, setWish] = useState<any>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");

  async function loadWish() {
    const { data, error } = await supabase
      .from("wishlist_items")
      .select("*")
      .eq("id", params.id)
      .single();

    if (error) {
      console.error(error);
      alert("Could not load wish.");
      router.push("/dashboard");
      return;
    }

    setWish(data);
    setTitle(data.title);
    setDescription(data.description);
    setPrice(String(data.price));
  }

  async function updateWish() {
    const { error } = await supabase
      .from("wishlist_items")
      .update({
        title,
        description,
        price: Number(price),
      })
      .eq("id", params.id);

    if (error) {
      alert(error.message);
      return;
    }

    alert("Wish updated successfully!");
    router.push("/dashboard");
  }

  async function deleteWish() {
    const confirmed = window.confirm(
      "Are you sure you want to delete this wish?"
    );

    if (!confirmed) return;

    const { error } = await supabase
      .from("wishlist_items")
      .delete()
      .eq("id", params.id);

    if (error) {
      alert(error.message);
      return;
    }

    alert("Wish deleted successfully!");
    router.push("/dashboard");
  }

  useEffect(() => {
    loadWish();
  }, []);

  if (!wish) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <p className="text-lg">Loading...</p>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gray-100">
      <div className="max-w-xl mx-auto p-8">
        <h1 className="text-3xl font-bold mb-6">Edit Wish</h1>

        <div className="bg-white rounded-xl shadow p-6 space-y-4">
          <div>
            <label className="block font-medium mb-1">Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full border rounded-lg p-3"
            />
          </div>

          <div>
            <label className="block font-medium mb-1">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className="w-full border rounded-lg p-3"
            />
          </div>

          <div>
            <label className="block font-medium mb-1">Price</label>
            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="w-full border rounded-lg p-3"
            />
          </div>

          <button
            onClick={updateWish}
            className="w-full bg-green-600 hover:bg-green-700 text-white rounded-lg p-3 font-semibold"
          >
            Update Wish
          </button>

          <button
            onClick={deleteWish}
            className="w-full bg-red-600 hover:bg-red-700 text-white rounded-lg p-3 font-semibold"
          >
            Delete Wish
          </button>
        </div>
      </div>
    </main>
  );
}