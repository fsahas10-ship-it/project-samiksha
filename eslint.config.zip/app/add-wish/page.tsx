"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabase";

export default function AddWishPage() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  async function handleSaveWish() {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    alert("Please login first.");
    return;
  }

  const { error } = await supabase
    .from("wishlist_items")
    .insert({
      user_id: user.id,
      title: title,
      description: description,
      price: price ? Number(price) : null,
    });

  if (error) {
    alert(error.message);
    return;
  }

  alert("Wish added successfully!");

  setTitle("");
  setDescription("");
  setPrice("");
}


  return (
    <main className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="w-full max-w-lg rounded-xl bg-white p-8 shadow">

        <h1 className="text-3xl font-bold mb-6">
          Add New Wish
        </h1>

        <div className="space-y-4">

          <input
            type="text"
            placeholder="Wish Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full border rounded-lg p-3"
          />

          <textarea
            placeholder="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full border rounded-lg p-3"
            rows={4}
          />

          <input
            type="number"
            placeholder="Estimated Price"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            className="w-full border rounded-lg p-3"
          />

          <button
  onClick={handleSaveWish}
  className="w-full bg-black text-white rounded-lg p-3"
>
          
            Save Wish
          </button>

        </div>

      </div>
    </main>
  );
}