"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";

export default function ProfilePage() {
  const router = useRouter();

  const [loading, setLoading] = useState(true);

  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  console.log(user);

  async function loadProfile() {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      router.push("/login");
      return;
    }

    const { data } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single();

    if (data) {
      setFullName(data.full_name || "");
      setUsername(data.username || "");
      setBio(data.bio || "");
      setAvatarUrl(data.avatar_url || "");
    }

    setLoading(false);
  }

  async function uploadAvatar(
    e: React.ChangeEvent<HTMLInputElement>
  ) {
    const file = e.target.files?.[0];

    if (!file) return;

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) return;

    const fileExt = file.name.split(".").pop();
    const fileName = `${user.id}.${fileExt}`;

    const { error } = await supabase.storage
      .from("avatars")
      .upload(fileName, file, {
        upsert: true,
      });

    if (error) {
      alert(error.message);
      return;
    }

    const {
      data: { publicUrl },
    } = supabase.storage
      .from("avatars")
      .getPublicUrl(fileName);

    setAvatarUrl(publicUrl);
  }

  async function saveProfile() {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) return;

    const { error } = await supabase
      .from("profiles")
      .upsert({
        id: user.id,
        full_name: fullName,
        username: username.toLowerCase().trim(),
        bio,
        avatar_url: avatarUrl,
      });

    if (error) {
      alert(error.message);
      return;
    }

    alert("Profile saved successfully!");
  }

  useEffect(() => {
    loadProfile();
  }, []);

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <h2 className="text-xl font-semibold">
          Loading...
        </h2>
      </main>
    );
  }

  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-gray-100 py-10">

        <div className="max-w-xl mx-auto bg-white rounded-xl shadow p-8">

          <h1 className="text-3xl font-bold mb-8">
            My Profile
          </h1>

          <div className="flex flex-col items-center mb-8">

            <img
              src={
                avatarUrl ||
                "https://placehold.co/150x150?text=Photo"
              }
              className="w-36 h-36 rounded-full object-cover border"
            />

            <input
              type="file"
              accept="image/*"
              onChange={uploadAvatar}
              className="mt-4"
            />

          </div>

          <div className="space-y-5">

            <div>

              <label className="block font-medium mb-2">
                Full Name
              </label>

              <input
                value={fullName}
                onChange={(e) =>
                  setFullName(e.target.value)
                }
                className="w-full border rounded-lg p-3"
              />

            </div>

            <div>

              <label className="block font-medium mb-2">
                Username
              </label>

              <input
                value={username}
                onChange={(e) =>
                  setUsername(e.target.value)
                }
                className="w-full border rounded-lg p-3"
              />

            </div>

            <div>

              <label className="block font-medium mb-2">
                Bio
              </label>

              <textarea
                rows={4}
                value={bio}
                onChange={(e) =>
                  setBio(e.target.value)
                }
                className="w-full border rounded-lg p-3"
              />

            </div>

            <button
              onClick={saveProfile}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-lg py-3"
            >
              Save Profile
            </button>

          </div>

        </div>

      </main>
    </>
  );
}