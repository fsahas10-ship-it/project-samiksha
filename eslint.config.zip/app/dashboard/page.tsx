"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import WishCard from "@/components/WishCard";
import Link from "next/link";

interface Wish {
  id: number;
  title: string;
  description: string;
  price: number;
}

export default function DashboardPage() {
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [wishes, setWishes] = useState<Wish[]>([]);
  const [name, setName] = useState("");

  async function loadDashboard() {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      router.push("/login");
      return;
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("full_name")
      .eq("id", user.id)
      .single();

    if (profile) {
      setName(profile.full_name || "");
    }

    const { data: wishes, error } = await supabase
      .from("wishlist_items")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (error) {
      console.error(error);
    } else {
      setWishes(wishes || []);
    }

    setLoading(false);
  }

  useEffect(() => {
    loadDashboard();
  }, []);

  if (loading) {
    return (
      <>
        <Navbar />

        <main className="min-h-screen flex items-center justify-center bg-gray-100">
          <h1 className="text-2xl font-bold">
            Loading...
          </h1>
        </main>
      </>
    );
  }

  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-gray-100">

        <section className="max-w-7xl mx-auto px-6 py-10">

          <div className="flex flex-col md:flex-row md:items-center md:justify-between">

            <div>

              <h1 className="text-5xl font-bold">
                Welcome{name ? `, ${name}` : ""} 👋
              </h1>

              <p className="text-gray-600 mt-3 text-lg">
                Manage your personal wishlist.
              </p>

            </div>

            <Link href="/add-wish">
              <button className="mt-6 md:mt-0 rounded-xl bg-blue-600 px-7 py-4 text-white font-semibold hover:bg-blue-700 transition">
                + Add New Wish
              </button>
            </Link>

          </div>

          <div className="mt-10">

            <h2 className="text-2xl font-bold">
              My Wishes ({wishes.length})
            </h2>

          </div>

          {wishes.length === 0 ? (
            <div className="bg-white rounded-2xl shadow mt-8 p-16 text-center">

              <h2 className="text-3xl font-bold">
                No Wishes Yet 🎁
              </h2>

              <p className="mt-4 text-gray-600">
                Click the button above and add your first wish.
              </p>

            </div>
          ) : (
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-8 mt-8">

              {wishes.map((wish) => (
                <WishCard
                  key={wish.id}
                  wish={wish}
                />
              ))}

            </div>
          )}

        </section>

      </main>
    </>
  );
}