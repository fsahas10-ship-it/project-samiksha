"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

export default function Navbar() {
  const router = useRouter();

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/login");
  }

  return (
    <nav className="bg-white shadow">
      <div className="max-w-6xl mx-auto flex items-center justify-between px-6 py-4">
        <Link
          href="/dashboard"
          className="text-2xl font-bold text-blue-600"
        >
          Project Samiksha
        </Link>

        <div className="flex gap-6 items-center">
          <Link
            href="/dashboard"
            className="hover:text-blue-600"
          >
            Dashboard
          </Link>

          <Link
            href="/add-wish"
            className="hover:text-blue-600"
          >
            Add Wish
          </Link>

          <Link
            href="/profile"
            className="hover:text-blue-600"
          >
            Profile
          </Link>

          <button
            onClick={handleLogout}
            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
          >
            Logout
          </button>
        </div>
      </div>
    </nav>
  );
}